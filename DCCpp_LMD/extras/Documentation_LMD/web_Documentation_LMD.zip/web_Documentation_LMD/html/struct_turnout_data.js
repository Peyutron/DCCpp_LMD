var struct_turnout_data =
[
    [ "address", "struct_turnout_data.html#a748ccb89448c3efd2b288d779ba231f4", null ],
    [ "id", "struct_turnout_data.html#a5a444c531b83c4aa95926a82b4c0f042", null ],
    [ "subAddress", "struct_turnout_data.html#ac5f5d5124dc7595c0717dd793031657a", null ],
    [ "tStatus", "struct_turnout_data.html#abc11a69999b966332b9d6f2314151ad1", null ]
];