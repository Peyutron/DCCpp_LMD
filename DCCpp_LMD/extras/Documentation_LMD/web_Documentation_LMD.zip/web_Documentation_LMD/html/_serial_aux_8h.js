var _serial_aux_8h =
[
    [ "SerialAux", "class_serial_aux.html", null ],
    [ "AUX_MAX_COMMAND_LENGTH", "_serial_aux_8h.html#aa02cdf40da937b5b154a0ef4c26aed30", null ],
    [ "SERIALAUX", "_serial_aux_8h.html#aba226b9801cc8af65f0c566af90a79d1", null ]
];