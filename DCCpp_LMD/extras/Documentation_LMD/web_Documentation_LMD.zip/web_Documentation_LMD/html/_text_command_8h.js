var _text_command_8h =
[
    [ "TextCommand", "struct_text_command.html", null ],
    [ "MAX_COMMAND_LENGTH", "_text_command_8h.html#af1abcb51a4aa27a5a5a7958c03448134", null ]
];