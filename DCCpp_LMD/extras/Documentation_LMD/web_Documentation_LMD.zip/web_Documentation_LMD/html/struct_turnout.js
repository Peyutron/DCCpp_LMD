var struct_turnout =
[
    [ "activate", "struct_turnout.html#a0e04446b041e822c04ae98f185d8febf", null ],
    [ "begin", "struct_turnout.html#a3e39c675007579c6db294a0e1f57f39d", null ],
    [ "inactivate", "struct_turnout.html#a01b4e8e33fc8fca0458f20beee2f1ed5", null ],
    [ "isActivated", "struct_turnout.html#a8d2cd012d42732e65333fa80592a20fb", null ],
    [ "set", "struct_turnout.html#ab7d51e1b8aa3cf3a862e3b500be3a88c", null ],
    [ "data", "struct_turnout.html#a404b78691015f78baf8183b0db3dc5a2", null ],
    [ "eepromPos", "struct_turnout.html#a8899396b83282ac85ab7b02cc4f37a1d", null ],
    [ "nextTurnout", "struct_turnout.html#ab1de16672bf5e622f93dc0316a6dd532", null ]
];