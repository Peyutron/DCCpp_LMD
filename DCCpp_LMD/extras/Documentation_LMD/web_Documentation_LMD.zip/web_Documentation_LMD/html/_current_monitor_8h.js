var _current_monitor_8h =
[
    [ "CurrentMonitor", "struct_current_monitor.html", "struct_current_monitor" ],
    [ "CURRENT_SAMPLE_SMOOTHING", "_current_monitor_8h.html#a087e9f69ff84cef6c065c09d92b6cdec", null ],
    [ "CURRENT_SAMPLE_TIME", "_current_monitor_8h.html#aa85f98758400b5602727b0a77a4b8c9b", null ]
];