var _config_8h =
[
    [ "DCCppConfig", "struct_d_c_cpp_config.html", null ],
    [ "MAX_CLIENTES", "_config_8h.html#a0cf5c23bdf46ca7f4778aea7da2bc548", null ],
    [ "MAX_PROG_REGISTERS", "_config_8h.html#a377fe26780e96d8192b6958166f3123b", null ],
    [ "MOTOR_SHIELD_CURRENT_MONITOR_PIN_MAIN", "_config_8h.html#af0619c7d65dcb6f3ed5e4a316488aa3c", null ],
    [ "MOTOR_SHIELD_CURRENT_MONITOR_PIN_PROG", "_config_8h.html#acfb88d6fc64fc6ac5c0dd7e3d0af388f", null ],
    [ "MOTOR_SHIELD_DIRECTION_MOTOR_CHANNEL_PIN_A", "_config_8h.html#ad3dd2f9689d6c60bc79bfa7268b3666d", null ],
    [ "MOTOR_SHIELD_DIRECTION_MOTOR_CHANNEL_PIN_B", "_config_8h.html#a6844b6185e17bf0691d8a448f466e018", null ],
    [ "MOTOR_SHIELD_SIGNAL_ENABLE_PIN_MAIN", "_config_8h.html#a9023ca4d4c26cb9844073ccd0c27af70", null ],
    [ "MOTOR_SHIELD_SIGNAL_ENABLE_PIN_PROG", "_config_8h.html#ae7e20442cdf850fc7e4da9939686e318", null ],
    [ "POLOLU_CURRENT_MONITOR_PIN_MAIN", "_config_8h.html#ac6dab93672a2311585379b218def7096", null ],
    [ "POLOLU_CURRENT_MONITOR_PIN_PROG", "_config_8h.html#a5c19b5cd28b29841ed7a3ec019904907", null ],
    [ "POLOLU_DIRECTION_MOTOR_CHANNEL_PIN_A", "_config_8h.html#af38ef2c7c76334f5f6c48acc5a5da421", null ],
    [ "POLOLU_DIRECTION_MOTOR_CHANNEL_PIN_B", "_config_8h.html#a52a3c003658863a04e377e2b2a5ed2ef", null ],
    [ "POLOLU_SIGNAL_ENABLE_PIN_MAIN", "_config_8h.html#aef7e96b0bca787fe1378b6002ee6384c", null ],
    [ "POLOLU_SIGNAL_ENABLE_PIN_PROG", "_config_8h.html#af2059e31c706265983cc02d27d7367f8", null ],
    [ "UNDEFINED_PIN", "_config_8h.html#a9cf5470f9ba14696b6fa4e3cca8e9d69", null ],
    [ "WIFI_PASSWORD", "_config_8h.html#a8685d8aff7e570048090a3a51afceb07", null ],
    [ "WIFI_SSID", "_config_8h.html#a586542b79d00e4db7e1d5a667ae83a2b", null ]
];