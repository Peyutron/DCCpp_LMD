var struct_packet =
[
    [ "buf", "struct_packet.html#a6cfcc974d95f0a6bee530517a5c9ad51", null ],
    [ "nBits", "struct_packet.html#a883cff7d134d63f66d59145300675b8f", null ]
];