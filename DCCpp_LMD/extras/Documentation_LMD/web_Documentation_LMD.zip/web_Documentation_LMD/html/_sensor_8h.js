var _sensor_8h =
[
    [ "SensorData", "struct_sensor_data.html", "struct_sensor_data" ],
    [ "Sensor", "struct_sensor.html", "struct_sensor" ],
    [ "SENSOR_DECAY", "_sensor_8h.html#a9ebe87204eb8086d73a7034a206b69ef", null ]
];