var struct_e_e_store_data =
[
    [ "id", "struct_e_e_store_data.html#a1478959f15e5412ef30842a0f6404ce5", null ],
    [ "nOutputs", "struct_e_e_store_data.html#ac3b033a0ed58d0d3be8dbcadc7c9fd6e", null ],
    [ "nSensors", "struct_e_e_store_data.html#a1b65880b2aefcb0023ceeeff3be95188", null ],
    [ "nTurnouts", "struct_e_e_store_data.html#a9401ce4adea47949d4a3435f729c06fb", null ]
];