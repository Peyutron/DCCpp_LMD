var _d_c_cpp___uno_8h =
[
    [ "DCCPP_INTERFACE", "_d_c_cpp___uno_8h.html#ad9941dff590104a145d58329c75a0041", null ],
    [ "VERSION", "_d_c_cpp___uno_8h.html#a1c6d5de492ac61ad29aec7aa9a436bbf", null ]
];