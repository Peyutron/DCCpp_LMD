var _d_c_cpp_8h =
[
    [ "DCCPP_LIBRARY_VERSION", "_d_c_cpp_8h.html#a8d9814dec9adda6df580a7f8fbebfa01", null ],
    [ "DCCPP_PRINT_DCCPP", "_d_c_cpp_8h.html#a974da9ef1ab28fef455505016a3caa57", null ],
    [ "USE_EEPROM", "_d_c_cpp_8h.html#abd7d46fa3888b2e1bed34df076372b30", null ],
    [ "USE_OLED", "_d_c_cpp_8h.html#af6533420f9f559dd86ecba5d0e76e834", null ],
    [ "USE_OUTPUT", "_d_c_cpp_8h.html#a6f8d193bd84df6f05773b458355e7bd8", null ],
    [ "USE_SENSOR", "_d_c_cpp_8h.html#a22f58986dc11249373f6ee1d5fb50c0a", null ],
    [ "USE_SERIALAUX", "_d_c_cpp_8h.html#a965f215e9e439aabf4a4745efc92a08f", null ],
    [ "USE_SERIALBLUETOOTH", "_d_c_cpp_8h.html#ab416e289e4e6705a8076f45b402c9c9f", null ],
    [ "USE_SERIALWIFI", "_d_c_cpp_8h.html#a1fb52428b5088ae30ed992dbacda581c", null ],
    [ "USE_TEXTCOMMAND", "_d_c_cpp_8h.html#ad7034344270036501578d215e708bc82", null ],
    [ "USE_TURNOUT", "_d_c_cpp_8h.html#a62257f60a9be8ccb699ec6f902c30630", null ]
];