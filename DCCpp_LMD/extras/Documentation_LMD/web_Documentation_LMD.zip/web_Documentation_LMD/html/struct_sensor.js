var struct_sensor =
[
    [ "begin", "struct_sensor.html#adcf987ab90ea531f8469ec25cbb14a85", null ],
    [ "isActive", "struct_sensor.html#ac38a51e9e7aa634503dcd32830931fac", null ],
    [ "set", "struct_sensor.html#a8bc88cdc22f1d5b2d67c1790dba8093f", null ],
    [ "active", "struct_sensor.html#ad2dcd5fa3886a4a9c7a5261e1a3ddb51", null ],
    [ "data", "struct_sensor.html#a4e4b92cf13d45726834a2e51c5b2ec74", null ],
    [ "nextSensor", "struct_sensor.html#ad242559dd9ddbba6dbc463e06364d6ca", null ],
    [ "signal", "struct_sensor.html#a03efc05452821e5fa4990bf6df365dba", null ]
];