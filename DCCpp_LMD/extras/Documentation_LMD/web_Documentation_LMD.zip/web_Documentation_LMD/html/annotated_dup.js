var annotated_dup =
[
    [ "Bluetooth", "class_bluetooth.html", null ],
    [ "CommManager", "class_comm_manager.html", null ],
    [ "CurrentMonitor", "struct_current_monitor.html", "struct_current_monitor" ],
    [ "DCCpp", "class_d_c_cpp.html", null ],
    [ "DCCppConfig", "struct_d_c_cpp_config.html", null ],
    [ "EEStore", "struct_e_e_store.html", null ],
    [ "EEStoreData", "struct_e_e_store_data.html", "struct_e_e_store_data" ],
    [ "FunctionsState", "class_functions_state.html", "class_functions_state" ],
    [ "Oled", "class_oled.html", null ],
    [ "Packet", "struct_packet.html", "struct_packet" ],
    [ "Register", "struct_register.html", "struct_register" ],
    [ "RegisterList", "struct_register_list.html", "struct_register_list" ],
    [ "Sensor", "struct_sensor.html", "struct_sensor" ],
    [ "SensorData", "struct_sensor_data.html", "struct_sensor_data" ],
    [ "SerialAux", "class_serial_aux.html", null ],
    [ "Sound", "class_sound.html", null ],
    [ "TextCommand", "struct_text_command.html", null ],
    [ "Turnout", "struct_turnout.html", "struct_turnout" ],
    [ "TurnoutData", "struct_turnout_data.html", "struct_turnout_data" ],
    [ "Wifi", "class_wifi.html", null ]
];