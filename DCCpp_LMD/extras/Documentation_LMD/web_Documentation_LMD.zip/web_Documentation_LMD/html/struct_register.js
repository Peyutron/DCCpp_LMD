var struct_register =
[
    [ "initPackets", "struct_register.html#a5ee802b8841361a04a988818ae956011", null ],
    [ "activePacket", "struct_register.html#a7c37978c106fd6fbe52c47f16498014f", null ],
    [ "packet", "struct_register.html#a66a305055571616e57916cd4eb8e8316", null ],
    [ "updatePacket", "struct_register.html#ab7784fb786f0c3737a941b620c55fdca", null ]
];