var searchData=
[
  ['comm_5fname_650',['COMM_NAME',['../_oled_8h.html#aaca6193f4329ac14971b2b69eab540d7',1,'Oled.h']]],
  ['current_5fsample_5fsmoothing_651',['CURRENT_SAMPLE_SMOOTHING',['../_current_monitor_8h.html#a087e9f69ff84cef6c065c09d92b6cdec',1,'CurrentMonitor.h']]],
  ['current_5fsample_5ftime_652',['CURRENT_SAMPLE_TIME',['../_current_monitor_8h.html#aa85f98758400b5602727b0a77a4b8c9b',1,'CurrentMonitor.h']]]
];
