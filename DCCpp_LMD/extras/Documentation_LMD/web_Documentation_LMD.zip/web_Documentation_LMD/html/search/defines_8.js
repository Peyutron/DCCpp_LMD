var searchData=
[
  ['oled_5fanimation_682',['OLED_ANIMATION',['../_oled_8h.html#a8da893152442ac3412142a37e1402e09',1,'Oled.h']]],
  ['oled_5fname_683',['OLED_NAME',['../_oled_8h.html#a85e64341412fbc0b0ca1a0679e26b22c',1,'Oled.h']]]
];
