var searchData=
[
  ['needsrefreshing_468',['needsRefreshing',['../struct_e_e_store.html#ac1a5510ab808789c2c89b9b62233fd83',1,'EEStore']]],
  ['nota_469',['nota',['../class_sound.html#ae219d5f1bbd8ed698d4d303647b4c794',1,'Sound']]]
];
