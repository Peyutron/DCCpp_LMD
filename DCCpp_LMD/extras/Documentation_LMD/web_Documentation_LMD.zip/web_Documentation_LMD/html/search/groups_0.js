var searchData=
[
  ['text_20commands_20syntax_715',['Text Commands Syntax',['../group__commands_group.html',1,'']]]
];
