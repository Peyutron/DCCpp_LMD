var searchData=
[
  ['n_5fdesvios_181',['N_DESVIOS',['../_oled_8h.html#ace07f75ca80fbb8928ceb87c969391a0',1,'Oled.h']]],
  ['nbits_182',['nBits',['../struct_packet.html#a883cff7d134d63f66d59145300675b8f',1,'Packet']]],
  ['needsrefreshing_183',['needsRefreshing',['../struct_e_e_store.html#ac1a5510ab808789c2c89b9b62233fd83',1,'EEStore']]],
  ['nelemento_184',['nElemento',['../_text_command_8cpp.html#ad8a3bf6436b90621ef85df63bb7e44e8',1,'TextCommand.cpp']]],
  ['nextreg_185',['nextReg',['../struct_register_list.html#a4aa3ecdb369ddf1428193f966eae81be',1,'RegisterList']]],
  ['nextsensor_186',['nextSensor',['../struct_sensor.html#ad242559dd9ddbba6dbc463e06364d6ca',1,'Sensor']]],
  ['nextturnout_187',['nextTurnout',['../struct_turnout.html#ab1de16672bf5e622f93dc0316a6dd532',1,'Turnout']]],
  ['nmenu_188',['nMenu',['../class_oled.html#a128e8388aeaf781e69a94d721a89b5e7',1,'Oled']]],
  ['nota_189',['nota',['../class_sound.html#ae219d5f1bbd8ed698d4d303647b4c794',1,'Sound']]],
  ['noutputs_190',['nOutputs',['../struct_e_e_store_data.html#ac3b033a0ed58d0d3be8dbcadc7c9fd6e',1,'EEStoreData']]],
  ['nrepeat_191',['nRepeat',['../struct_register_list.html#a1040a48f0519eb56c491754933ec90bf',1,'RegisterList']]],
  ['nsensors_192',['nSensors',['../struct_e_e_store_data.html#a1b65880b2aefcb0023ceeeff3be95188',1,'EEStoreData']]],
  ['nturnouts_193',['nTurnouts',['../struct_e_e_store_data.html#a9401ce4adea47949d4a3435f729c06fb',1,'EEStoreData']]]
];
