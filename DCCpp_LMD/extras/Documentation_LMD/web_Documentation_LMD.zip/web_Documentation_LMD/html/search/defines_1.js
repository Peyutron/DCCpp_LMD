var searchData=
[
  ['bluetooth_648',['BLUETOOTH',['../_serial_bluetooth_8h.html#a3f30897fa8435dc9811642367a328be8',1,'SerialBluetooth.h']]],
  ['bt_5fmax_5fcommand_5flength_649',['BT_MAX_COMMAND_LENGTH',['../_serial_bluetooth_8h.html#ace79b57188adf51b0ba19d4d70d1b9fb',1,'SerialBluetooth.h']]]
];
