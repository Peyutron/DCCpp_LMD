var searchData=
[
  ['s_5f88_693',['S_88',['../_oled_8h.html#aa58587ce4baa29586b91e675a8023dc3',1,'Oled.h']]],
  ['salidas_694',['SALIDAS',['../_oled_8h.html#a9f0782b2993cec09bc03ce7275523b02',1,'Oled.h']]],
  ['sensor_5fdecay_695',['SENSOR_DECAY',['../_sensor_8h.html#a9ebe87204eb8086d73a7034a206b69ef',1,'Sensor.h']]],
  ['sensores_696',['SENSORES',['../_oled_8h.html#abb02c315e8aa1101261388c0318b7823',1,'Oled.h']]],
  ['serialaux_697',['SERIALAUX',['../_serial_aux_8h.html#aba226b9801cc8af65f0c566af90a79d1',1,'SerialAux.h']]]
];
