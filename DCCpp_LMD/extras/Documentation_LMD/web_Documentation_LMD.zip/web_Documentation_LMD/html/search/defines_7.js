var searchData=
[
  ['n_5fdesvios_681',['N_DESVIOS',['../_oled_8h.html#ace07f75ca80fbb8928ceb87c969391a0',1,'Oled.h']]]
];
