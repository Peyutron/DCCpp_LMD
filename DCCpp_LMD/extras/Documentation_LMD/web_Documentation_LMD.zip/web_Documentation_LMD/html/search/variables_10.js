var searchData=
[
  ['temppacket_633',['tempPacket',['../struct_register_list.html#a6a87974dadffdd85e3bd21a4fb9c77df',1,'RegisterList']]],
  ['timerpantalla_634',['timerpantalla',['../_oled_8cpp.html#a0c16721eff14179d1cb07220b4037d1f',1,'Oled.cpp']]],
  ['tstatus_635',['tStatus',['../struct_turnout_data.html#abc11a69999b966332b9d6f2314151ad1',1,'TurnoutData::tStatus()'],['../_oled_8cpp.html#a495041e8412424fa6b6248c7d433cd19',1,'tStatus():&#160;Oled.cpp']]],
  ['turnoutstatus_636',['turnoutStatus',['../_oled_8cpp.html#aabb1bc0f36cfba3144a6f974b61b9ed2',1,'Oled.cpp']]]
];
