var searchData=
[
  ['v_638',['v',['../_text_command_8cpp.html#ac8859e8c1ce357c4c8b37bbb1936ba1c',1,'TextCommand.cpp']]]
];
