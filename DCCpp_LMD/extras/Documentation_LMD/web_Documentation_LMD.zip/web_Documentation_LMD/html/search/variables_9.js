var searchData=
[
  ['lastclient_587',['lastClient',['../_serial_wifi_8cpp.html#a4a22520ee4254279c799586abb08130f',1,'SerialWifi.cpp']]]
];
