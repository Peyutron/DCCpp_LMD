var _packet_register_8h =
[
    [ "Packet", "struct_packet.html", "struct_packet" ],
    [ "Register", "struct_register.html", "struct_register" ],
    [ "RegisterList", "struct_register_list.html", "struct_register_list" ],
    [ "ACK_BASE_COUNT", "_packet_register_8h.html#ad5230dc25c9617f7ee18052042551f9f", null ],
    [ "ACK_SAMPLE_COUNT", "_packet_register_8h.html#aa11f1b06419bf44060cf24dad4223c38", null ],
    [ "ACK_SAMPLE_SMOOTHING", "_packet_register_8h.html#a53c971f7d89fd2fafa93831b7570b21c", null ],
    [ "ACK_SAMPLE_THRESHOLD", "_packet_register_8h.html#ae8b945a277441e7dc6860b332e5e9130", null ]
];