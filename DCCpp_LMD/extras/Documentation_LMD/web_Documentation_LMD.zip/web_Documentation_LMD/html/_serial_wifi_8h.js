var _serial_wifi_8h =
[
    [ "Wifi", "class_wifi.html", null ],
    [ "WF_MAX_COMMAND_LENGTH", "_serial_wifi_8h.html#ae97bf145fce41c80690a2f845fd0218a", null ],
    [ "WIFI", "_serial_wifi_8h.html#a14ed8168071c3bb8602b38ecb1b28178", null ]
];