var struct_sensor_data =
[
    [ "pin", "struct_sensor_data.html#a38168d6e9536f80c0bd818ea7701bd35", null ],
    [ "pullUp", "struct_sensor_data.html#af6c7ef984646e6aa041bf96ff30198ed", null ],
    [ "snum", "struct_sensor_data.html#a8c649835983803786f3c862a3a213194", null ]
];