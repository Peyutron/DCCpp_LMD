var struct_current_monitor =
[
    [ "begin", "struct_current_monitor.html#aec4b8f83dd8d5715a9ae21411633c697", null ],
    [ "check", "struct_current_monitor.html#a485def380e9c87c17dc2f1c8720e005a", null ],
    [ "current", "struct_current_monitor.html#a5d7913a8c985e532b36962d2088cb676", null ],
    [ "currentSampleMax", "struct_current_monitor.html#a12b999d776526131f8d008d3396589ff", null ],
    [ "msg", "struct_current_monitor.html#a0d39b1f9324033a87094feebd2b1b501", null ],
    [ "pin", "struct_current_monitor.html#a75c7b76d3cbc8207f6f77ef2b6e35301", null ],
    [ "signalPin", "struct_current_monitor.html#aeb5272629eb9b4e810b8f7f21651a6f4", null ]
];