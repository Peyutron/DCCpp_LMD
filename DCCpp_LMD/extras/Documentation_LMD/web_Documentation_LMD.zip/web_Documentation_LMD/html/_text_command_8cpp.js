var _text_command_8cpp =
[
    [ "__brkval", "_text_command_8cpp.html#a8d18204366e8a385c441663ed41f1ae4", null ],
    [ "__heap_start", "_text_command_8cpp.html#aa84b5136d382ee274a86572892e5e007", null ],
    [ "info_serial", "_text_command_8cpp.html#ad0efaece3441ddf4ba8b43aca226adc3", null ],
    [ "info_vers", "_text_command_8cpp.html#a38ffd11f092b27f5af50ac2166b6d96e", null ],
    [ "memoria", "_text_command_8cpp.html#a375d9a073255ba403e27c4f925e139a7", null ],
    [ "nElemento", "_text_command_8cpp.html#ad8a3bf6436b90621ef85df63bb7e44e8", null ],
    [ "serialInUse", "_text_command_8cpp.html#a227bdf2075b5e966a97715b214c04a44", null ],
    [ "v", "_text_command_8cpp.html#ac8859e8c1ce357c4c8b37bbb1936ba1c", null ]
];