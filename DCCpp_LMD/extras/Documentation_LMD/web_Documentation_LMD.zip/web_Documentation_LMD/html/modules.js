var modules =
[
    [ "Text Commands Syntax", "group__commands_group.html", [
      [ "@mainpage", "common_page.html#autotoc_md0", null ]
    ] ]
];