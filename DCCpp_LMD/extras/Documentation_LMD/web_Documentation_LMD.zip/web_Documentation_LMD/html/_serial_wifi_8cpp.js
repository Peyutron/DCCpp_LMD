var _serial_wifi_8cpp =
[
    [ "bytesEsperados", "_serial_wifi_8cpp.html#aadb5c4d9e9af3576e93d7de6743a7de0", null ],
    [ "clienteConectado", "_serial_wifi_8cpp.html#a659a7e5d89e4fbc5ded1def719d308f8", null ],
    [ "conexionId", "_serial_wifi_8cpp.html#a2adc17d7178856728a897ae0efe54dec", null ],
    [ "lastClient", "_serial_wifi_8cpp.html#a4a22520ee4254279c799586abb08130f", null ]
];